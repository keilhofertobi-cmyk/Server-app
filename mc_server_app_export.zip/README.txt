Minecraft Server App Project

This is a minimal export for APK building.